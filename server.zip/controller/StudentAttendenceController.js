// model -- AttendenceSchema


// const getAttendence = async (req, res) = {

// }

// const addAttendence = async (req, res) = {

// }

// const editAttendence = async (req, res) = {

// }

// const deleteAttendence = async (req, res) = {

// }

// export { getAttendence }
// export { getAttendence, addAttendence, editAttendence, deleteAttendence }